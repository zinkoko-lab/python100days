def mymod2func():
    print("This is mymod2func.")


if __name__ == "__main__":
    mymod2func()