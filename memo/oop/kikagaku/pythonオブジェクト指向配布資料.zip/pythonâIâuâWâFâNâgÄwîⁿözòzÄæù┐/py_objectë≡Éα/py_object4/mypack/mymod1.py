def mymod1func():
    print("This is mymod1func.")

if __name__ == "__main__":
    mymod1func()