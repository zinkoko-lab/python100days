import module1 as m
m.print_message()

from module1 import print_message as pm
pm()