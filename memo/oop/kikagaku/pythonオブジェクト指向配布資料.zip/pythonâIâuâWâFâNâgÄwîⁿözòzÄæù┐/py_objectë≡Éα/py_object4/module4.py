import mypack.mymod1

mypack.mymod2.mymod2func()