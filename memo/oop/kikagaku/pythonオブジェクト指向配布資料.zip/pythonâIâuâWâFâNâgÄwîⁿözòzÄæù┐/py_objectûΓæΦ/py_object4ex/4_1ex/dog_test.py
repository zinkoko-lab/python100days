import dog

d1 = dog.Dog("ポチ")
d1.show()
s1 = dog.Superdog("ハチ")
s1.show()