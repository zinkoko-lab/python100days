import dog1

d1 = dog1.Dog("ポチ")
d1.show()
s1 = dog1.Superdog("ハチ")
s1.show()