# 名前を読み込んで挨拶（別解）

name = input('お名前は：')

print(f'こんにちは{name}さん。')
