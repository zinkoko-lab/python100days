# 名前を読み込んで挨拶

print('お名前は：', end='')
name = input()

print(f'こんにちは{name}さん。')
