# 1から12までを8をスキップして繰り返す（その３）

for i in *list(range(1, 8)), *list(range(9, 13)):
    print(i, end=' ')
print()
