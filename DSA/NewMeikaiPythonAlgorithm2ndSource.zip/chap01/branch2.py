# 整数値の判定（その２）

n = int(input('整数：'))

if n == 1:
    print('Ａ')
elif n == 2:
    print('Ｂ')
elif n == 3:
    print('Ｃ')
