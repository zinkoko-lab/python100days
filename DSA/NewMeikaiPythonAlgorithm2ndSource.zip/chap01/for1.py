# 1から100まで繰り返して表示

for i in range(1, 101):
    print(f'{i = :3}  {id(i) = }')
