# 整数値の判定（その１）

n = int(input('整数：'))

if n == 1:
    print('Ａ')
elif n == 2:
    print('Ｂ')
else:
    print('Ｃ')
