# 整数値の判定（その２の正体）

n = int(input('整数：'))

if n == 1:
    print('Ａ')
elif n == 2:
    print('Ｂ')
elif n == 3:
    print('Ｃ')
else:
    pass
