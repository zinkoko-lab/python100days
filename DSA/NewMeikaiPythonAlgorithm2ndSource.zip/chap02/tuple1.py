# タプルの全要素を走査（要素数を事前に取得）

x = ('John', 'George', 'Paul', 'Ringo')

for i in range(len(x)):
    print(f'x[{i}] = {x[i]}')
