# リストの全要素を走査（インデックス値を使わない）

x = ['John', 'George', 'Paul', 'Ringo']

for i in x:
    print(i)
